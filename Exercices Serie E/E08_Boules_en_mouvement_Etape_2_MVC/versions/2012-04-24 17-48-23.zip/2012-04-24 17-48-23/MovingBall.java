/**
 * Write a description of class "MovingBall" here.
 * 
 * @author     robertfisch
 * @version    24/04/2012 17:47:13
 */
public class MovingBall extends Ball
{

	private int xDir;

	private int yDir;

	private int step;


	public int getXDir()
	{
		return xDir;
	}

	public void setXDir(int pXDir)
	{
		xDir = pXDir;
	}

	public int getYDir()
	{
		return yDir;
	}

	public void setYDir(int pYDir)
	{
		yDir = pYDir;
	}

	public int getStep()
	{
		return step;
	}

	public void setStep(int pStep)
	{
		step = pStep;
	}
}