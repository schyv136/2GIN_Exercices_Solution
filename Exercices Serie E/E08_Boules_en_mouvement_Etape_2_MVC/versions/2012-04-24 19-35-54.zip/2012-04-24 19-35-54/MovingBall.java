/**
 * Cette classe représente une boule en mouvement.
 * La classe elle-même ne connait pas son environnement.
 * C'est donc l'environnement qui est en charge de "diriger" la boule.
 * 
 * @author     robertfisch
 * @version    24/04/2012 17:47:13
 */
public class MovingBall extends Ball
{

	private int xDir = 1;

	private int yDir = 1;

	private int step;

	public int getStep()
	{
		return step;
	}

	public void setStep(int pStep)
	{
		step = pStep;
	}

	public void invertXDirection()
	{
		xDir=-xDir;
	}

	public void invertYDirection()
	{
		yDir=-yDir;
	}

	public int getNextX()
	{
		return getX()+xDir*step;
	}

	public int getNextY()
	{
		return getY()+yDir*step;
	}


	public void doStep()
	{
		setX(getNextX());
		setY(getNextY());
	}
}