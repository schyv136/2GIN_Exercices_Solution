/**
 * Cette classe représente une boule en mouvement.
 * La classe elle-même ne connait pas son environnement.
 * C'est donc l'environnement qui est en charge de "diriger" la boule.
 * 
 * @author     robertfisch
 * @version    24/04/2012 17:47:13
 */
public class MovingBall extends Ball
{

	private int xDir;

	private int yDir;

	private int step;


	public int getXDir()
	{
		return xDir;
	}

	public void setXDir(int pXDir)
	{
		xDir = pXDir;
	}

	public int getYDir()
	{
		return yDir;
	}

	public void setYDir(int pYDir)
	{
		yDir = pYDir;
	}

	public int getStep()
	{
		return step;
	}

	public void setStep(int pStep)
	{
		step = pStep;
	}

	public int getNextX()
	{
		return getX()+xDir*step;
	}

	public int getNextY()
	{
		return getY()+yDir*step;
	}


	public void doStep()
	{
		setX(getNextX());
		setY(getNextY());
	}
}