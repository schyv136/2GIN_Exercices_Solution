import java.util.Calendar;

/**
 * Mémorisation du temps en heures et minutes
 *
 * @author Michel Mercatoris & Fred Faber & Jens Getreu
 * @version 30/12/2011
 */
public class UniversalTime {

    /**
     * les heures
     */
    private int hours;
    /**
     * les minutes
     */
    private int minutes;
    /**
     * difference to UTC Time
     */
    private int diffUTC;

    /**
     * constructeur
     *
     * @param pHours	l'heure
     * @param pMinutes	les minutes
     * @param pDiffUTC
     */
    public UniversalTime(int pHours, int pMinutes, int pDiffUTC) {
        minutes = pMinutes;
        hours = pHours;
        diffUTC = pDiffUTC;
    }

    /**
     * constructeur
     *
     * @param pDiffUTC
     */
    public UniversalTime(int pDiffUTC) {
        diffUTC = pDiffUTC;
        //Créer une nouvelle instance cal de la classe prédéfinie Calendar
        Calendar cal = Calendar.getInstance();
        // Utiliser l'instance cal pour obtenir l'heure et les minutes actuelles
        hours = cal.get(Calendar.HOUR_OF_DAY);
        minutes = cal.get(Calendar.MINUTE);
    }

    /**
     * retourne le temps actuel en minutes
     *
     * @return le temps actuel en minutes
     */
    public int getTimeInMinutes() {
        return minutes + hours * 60;
    }

    /**
     * Initialise le temps actuel par le temps actuel (de l'ordinateur) Ici, on
     * profite de la classe java.util.Calendar (qui doit être importée avant la
     * définition de la classe)
     */
    public void setToSystemTime() {
        //Faire créer une nouvelle instance cal de la classe prédéfinie Calendar
        Calendar cal = Calendar.getInstance();
        // Utiliser l'instance cal pour obtenir l'heure et les minutes actuelles
        hours = cal.get(Calendar.HOUR_OF_DAY);
        minutes = cal.get(Calendar.MINUTE);
    }

    public String getLocalTime() {
        return valueOf(hours, minutes);
    }

    public String getUtcTime() {
        return valueOf((24 + hours - diffUTC) % 24, minutes);
    }

    public String getNewYorkTime() {
        return valueOf((24 + hours - diffUTC - 5) % 24, minutes);
    }

    public String getTallinnTime() {
        return valueOf((24 + hours - diffUTC + 2) % 24, minutes);
    }

    public String getLosAngelesTime() {
        return valueOf((24 + hours - diffUTC - 8) % 24, minutes);
    }

    public String getBangkokTime() {
        return valueOf((24 + hours - diffUTC + 7) % 24, minutes);
    }

    public String getMoscowTime() {
        return valueOf((24 + hours - diffUTC + 4) % 24, minutes);
    }

    public String getDelhiTime() {
        int h = hours - diffUTC + 5;
        int m = minutes + 30;
        if (m >= 60) {
            m = m - 60;
            h = h + 1;
        }
         //ou bien :
        //h = hours+diffUTC+5+(minutes+30)/60;
        //m = (minutes+30)%60;
        return valueOf((24 + h) % 24, m);
    }

    /**
     * Retourner comme texte le temps passé comme paramètre
     *
     * @return	texte contenant le temps donné
     */
    private String valueOf(int pHours, int pMinutes) {
        return pHours + ":" + pMinutes + "h";
    }

    /**
     * Retourner comme texte le temps actuel ainsi que le temps en minutes
     *
     * @return	texte contenant le temps actuel ainsi que le temps en minutes
     */
    @Override
    public String toString() {
        return hours + ":" + minutes + "h (" + getTimeInMinutes() + " minutes) diffUTC:" + diffUTC;
    }
}