/**
 * La classe “AnalyseInt“ sert à exécuter différents tests sur un nombre entier.
 * La classe ne possède un attribut sur lequel s'effectuent tous les tests 
 * 
 * @author     fabfr
 * @version    18/05/2011 
 */
public class AnalyseInt
{

	/** The target number for all operations */
	private int n;

    /**
	 * Retourne true ssi le nombre n est divisible par deux
	 * @return     la parité
	 */
    public boolean isEven() 
    {
        //version 1 :
        if (n%2==0) 
        	return true;
        else 
        	return false;

        //version 2 : - la plus élégante -
        // return n%2==0;
     }

    /**
	 * Retourne true ssi le nombre n possède exactement deux diviseurs
	 * @return   true ssi le nombre est premier
	 */
    public boolean isPrime() 
    {
        //Version 1 -la plus lente-
		int nDivi=0;
		for (int i=1 ; i<=n ; i++)
		{
			if (n%i == 0) nDivi++;
		}
		return nDivi == 2;
		
			
		/* Version 2: -très rapide-
		   Idée: Tester s'il existe un diviseur >1 et <n
		   Dans ce cas on peut s'arrêter de tester à sqrt(n), car
		   s'il n'existe pas de diviseur <= sqrt(n), alors
		   il ne peut pas exister de diviseur >sqrt(n) et <n ...
		 */
		 
	/*
		int i=2;
		while (i<=Math.sqrt(n)  &&  n%i != 0) i++;
		return  n==2 || n%i!=0 && n>1;
		//Les conditions n==2 et n>1 sont nécessaires pour 
		//que la méthode retourne aussi un résultat correct 
		//pour n=1(false) et n=2 (true)
	 */
    }

    /**
	 * Retourne la somme des diviseurs du nombre   
	 * @return   la somme des diviseurs de n
	 */
    public int sumOfDividers() 
    {
          int sumDiv=0;
		for (int i=1 ; i<=n ; i++)
		{
			if (n%i == 0) sumDiv = sumDiv + i;
		}
		return sumDiv;
    }

    /**
	 * Retourne true ssi la somme des diviseurs du nombre  
	 * est égale au double du nombre
	 * @return   true ssi n est parfait
	 */
    public boolean isPerfect() 
    {
        return sumOfDividers() == 2*n;
    }

    /**
	 * Retourne true ssi la somme des diviseurs du nombre  
	 * est strictement inférieure au double du nombre
	 * @return   true ssi le nombre est déficient
	 */
    public boolean isDeficient() 
    {
        return sumOfDividers() < 2*n;
    }

    /**
	 * Retourne true ssi la somme des diviseurs du nombre 
	 * est strictement supérieure au double du nombre
	 * @return   true ssi le nombre est abondant
	 */
    public boolean isAbundant() 
    {
        return sumOfDividers() > 2*n;
    }

    /**
	 * Retourne true ssi la somme des diviseurs de deux nombres donnés est identique 
	 * @param pM  le nombre à comparer avec n
	 * @return   true ssi les nombres pM et n sont amicaux
	 */
    public boolean isFriendlyTo(int pM) 
    {
    	   //comme on ne peut pas appliquer sumOfDividers à pM, 
    	   //la méthode la plus simple est de calculer
    	   //la somme des diviseurs de M par une boucle.
    	     int sumDivM=0;
		for (int i=1 ; i<=n ; i++)
			if (n%i == 0) sumDivM = sumDivM + i;
     	return sumOfDividers() == sumDivM;	//true ssi les nombres sont amicuax
    }

    /**
     * Renverse l'ordre des chiffres dans n
     */
    public void reverse()
    {
    		int res=0;
    		while (n!=0)
    		{
    			res = n%10 + res*10;
    			n=n / 10;
    		}
    		n = res;
    }

    /**
     * Retourne true ssi le nombre donné est un palindrome 
     */
    public boolean isPalindrome(int n)
    {
    	reverse();	//renverser le nombre n
    	int rev = n;	//mémoriser le nombre renversé
    	reverse();	//remettre le nombre n dans son état original    	
    	return n==rev; //true ssi la version renversée est égale au nombre
    }


}