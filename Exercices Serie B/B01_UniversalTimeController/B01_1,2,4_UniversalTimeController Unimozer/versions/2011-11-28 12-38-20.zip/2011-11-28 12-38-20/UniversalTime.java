/**
 * mémorisation d'une heure et des minutes
 * 
 * @author     michelmercatoris, getreu
 * @version    04/09/2011 10:50:33
 */
public class UniversalTime
{

	protected int minutes;
	protected int hours;

	public UniversalTime(int pHours, int pMinutes)
	{
		minutes = pMinutes;
		hours   = pHours;
	}

	public int getTimeInMinutes()
	{
		return minutes +  hours * 60;
	}
	
	public String toString()
	{
		return hours+":"+minutes+"h ("+ getTimeInMinutes() +" minutes)";
	}
}