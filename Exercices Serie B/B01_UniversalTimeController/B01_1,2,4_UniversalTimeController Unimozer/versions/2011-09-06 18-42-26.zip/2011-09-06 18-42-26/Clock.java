/**
 * Write a description of class "Clock" here.
 * 
 * @author     michelmercatoris
 * @version    04/09/2011 10:50:33
 */
public class Clock
{

	protected int minutes;
	protected int hours;

	public Clock(int pHours, int pMinutes)
	{
		minutes = pMinutes;
		hours   = pHours;
	}

	public int getTimeInMinutes()
	{
		return minutes +  hours * 60;
	}
	
	public String toString()
	{
		return hours+":"+minutes+"h ("+ getTimeInMinutes() +" minutes)";
	}
}