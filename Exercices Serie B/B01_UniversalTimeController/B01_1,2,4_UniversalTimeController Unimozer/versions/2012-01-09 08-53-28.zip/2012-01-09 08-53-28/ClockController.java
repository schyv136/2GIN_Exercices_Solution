/**
 * Write a description of class "CallClock" here.
 * 
 * @author     michelmercatoris
 * @version    06/09/2011 08:35:05
 */
public class ClockController
{

	public  void run()
	{
	   UniversalTime utc = new UniversalTime(12, 20);
           System.out.println(utc);
	}
}