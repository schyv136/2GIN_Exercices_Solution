/**
 * Création automatique d'une instance de Clock
 * 
 * @author     fred
 * @version    06/09/2011 18:47:30
 */
public class ClockApp
{
    /**
	 * The main entry point for executing this program.
	 */
    public static void main(String[] args) 
    {
	   Clock myClock = new Clock(12,20);
        System.out.println(myClock);	
    }
}