/**
 * Write a description of class "Clock" here.
 * 
 * @author     michelmercatoris
 * @version    04/09/2011 10:50:33
 */
public class Clock
{

	/**
	 * Write a description of field "minutes" here.
	 */
	protected int minutes;

	/**
	 * Write a description of field "hours" here.
	 */
	protected int hours;

	/**
	 * Write a description of this constructor here.
	 * 
	 * @param pHours      a description of the parameter "pHours  "
	 * @param pMinutes    a description of the parameter "pMinutes"
	 */
	public Clock(int pHours, int pMinutes)
	{
		minutes = pMinutes;
		hours = pHours;
	}

	/**
	 * Write a description of method "toString" here.
	 * 
	 * @return                a description of the returned result
	 */
	public String toString()
	{
		return minutes + " m and " + hours + "h";
	}
}