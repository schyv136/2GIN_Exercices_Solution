/**
 * Write a description of class "CallUpClock" here.
 * 
 * @author     michelmercatoris
 * @version    06/09/2011 08:35:05
 */
public class CallUpClockUnimozer
{

	/**
	 * Write a description of method "Call" here.
	 * 
	 */
	public void CallUp()
	{
	   Clock myClock = new Clock(12,50);
        System.out.println(myClock);	
	}
}