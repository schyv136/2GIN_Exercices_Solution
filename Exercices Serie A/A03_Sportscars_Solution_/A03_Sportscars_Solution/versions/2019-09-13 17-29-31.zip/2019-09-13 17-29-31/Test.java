/**
 * Write a description of class "Test" here.
 * 
 * @author     georges
 * @version    16/08/2019 19:18:20
 */
public class Test
{

    /**
	 * The main entry point for executing this program.
	 */
    public static void main(String[] args)
	{
		Person georges = new Person("Georges", 25);
		Person aly = new Person("Aly", 43);
		Person angelina = new Person("Angelina", 23);
		
		SportsCar bugatti = new SportsCar("Bugatti","Divo");
		SportsCar lamborghini = new SportsCar("Lamborghini", "Aventador");

		Unimozer.monitor(georges,"georges");
		Unimozer.monitor(aly,"aly");
		Unimozer.monitor(angelina,"angelina");
		Unimozer.monitor(bugatti,"bugatti");
		Unimozer.monitor(lamborghini,"lamborghini");
    }
}