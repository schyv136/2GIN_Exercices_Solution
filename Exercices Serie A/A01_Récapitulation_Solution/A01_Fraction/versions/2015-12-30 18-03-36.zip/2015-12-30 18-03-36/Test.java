public class Test
{

    public static void main(String[] args) 
    {
 		Fraction fraction0 = new Fraction(150 , 120);
        System.out.println(fraction0.gcd());
 		System.out.println("Fraction 0 (avant) = " + fraction0);
 		Fraction fraction1 = new Fraction(24 , 42);
 		System.out.println(fraction1.gcd());
 		System.out.println("Fraction 1 (avant) = " + fraction1);
 		
 		fraction0.add( fraction1 ); 
 		
 		System.out.println("Fraction 0 (après...)= " + fraction0);
	}


/*
    public static void main(String[] args) 
    {
 		Fraction fraction0 = new Fraction(12 , 15);
 		System.out.println("Fraction 0 (avant) = " + fraction0);
 		
 		fraction0.add( new Fraction(24 , 42) );
 		
 		System.out.println("Fraction 0 (après) = "+fraction0);
	}
*/
	
}