/**
 * Write a description of class "SongList" here.
 * 
 * @author     robertfisch
 * @version    18/10/2011 20:52:08
 */
public abstract class SongList
{

	protected ArrayList<Song> songs;

	public int calculateDuration()
	{
	}
}