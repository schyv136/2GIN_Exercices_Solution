/**
 * Write a description of class "Cd" here.
 * 
 * @author     robertfisch
 * @version    18/10/2011 20:52:01
 */
public class Cd extends SongList
{

	protected int capacity = 74;

	public void addSong(Song song)
	{
		if(calculateDuration()+song.getDuration()<capacity)
			songs.add(song);
	}
	

}