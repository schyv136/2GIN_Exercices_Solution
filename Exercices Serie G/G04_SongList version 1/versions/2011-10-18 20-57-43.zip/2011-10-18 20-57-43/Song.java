/**
 * Write a description of class "Song" here.
 * 
 * @author     robertfisch
 * @version    18/10/2011 20:48:31
 */
public class Song
{

	protected int duration;

	protected String artist;

	protected boolean Title;

	public int getDuration()
	{
		return duration;
	}

	public void setDuration(int pDuration)
	{
		duration = pDuration;
	}

	public String getArtist()
	{
		return artist;
	}

	public void setArtist(String pArtist)
	{
		artist = pArtist;
	}

	public boolean isTitle()
	{
		return Title;
	}

	public void setTitle(boolean pTitle)
	{
		Title = pTitle;
	}
}