/**
 * Write a description of class "Cd" here.
 * 
 * @author     robertfisch
 * @version    18/10/2011 20:52:01
 */
public class Cd extends SongList
{
}