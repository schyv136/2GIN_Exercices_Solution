/**
 * Write a description of class "Song" here.
 * 
 * @author     robertfisch
 * @version    18/10/2011 20:48:31
 */
public class Song
{

	protected int duration;

	protected String artist;

	protected String title;

	public Song(String pTitle, String pArtist, int pDuration)
	{
		setTitle(pTitle);
		setArtist(pArtist);
		setDuration(pDuration);
	}

	public int getDuration()
	{
		return duration;
	}

	public void setDuration(int pDuration)
	{
		duration = pDuration;
	}

	public String getArtist()
	{
		return artist;
	}

	public void setArtist(String pArtist)
	{
		artist = pArtist;
	}

	public String istitle()
	{
		return title;
	}

	public void setTitle(String pTitle)
	{
		title = pTitle;
	}

	public String toString()
	{
		return title+" - "+artist+" ("+duration+")";
	}
}