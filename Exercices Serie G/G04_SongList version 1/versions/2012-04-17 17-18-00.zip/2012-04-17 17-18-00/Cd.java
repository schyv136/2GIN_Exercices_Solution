/**
 * Write a description of class "Cd" here.
 * 
 * @author     robertfisch
 * @version    18/10/2011 20:52:01
 */
public class Cd extends SongList
{

	protected int capacity = 74*60;

	public void addSong(Song song)
	{
		if(!songs.contains(song))
			if(calculateDuration()+song.getDuration()<capacity)
				songs.add(song);
	}

}