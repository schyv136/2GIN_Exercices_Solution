/**
 * Write a description of class "Cd" here.
 * 
 * @author     robertfisch
 * @version    18/10/2011 20:52:01
 */
public class Cd extends SongList
{

	/** capacity in seconds */
	protected int capacity = 74*60;

	public Cd()
	{
		// do nothing (standard capacity)
	}

	public Cd(int pCapacity)
	{
		capacity=pCapacity;
	}

	/**
	 * adds a new song to the CD
	 * @param	pSong	the song to be added
	 */
	public void addSong(Song pSong)
	{
		if(!getSongs().contains(pSong))
			if(calculateDuration()+pSong.getDuration()<=capacity)
				getSongs().add(pSong);
	}

	public void setCapacity(int pCapacity)
	{
		capacity=pCapacity;
	}

	public int getCapacity()
	{
		return capacity;
	}

}