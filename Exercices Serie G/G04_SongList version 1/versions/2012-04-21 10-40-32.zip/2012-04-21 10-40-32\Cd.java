/**
 * Cette classe représente un CD.
 * 
 * @author     robertfisch
 * @version    18/10/2011 20:52:01
 */
public class Cd extends SongList
{

	/** la capacity en secondes */
	private int capacity = 74*60;

	/** 
	 *  crée un nouveau CD avec la capacité standard
	 */
	public Cd()
	{
		// do nothing (standard capacity)
	}

	/**
	 * crée un nouveau CD avec un capacity donnée
	 * @param	pCapacity	la capacité du CD en secondes
	 */
	public Cd(int pCapacity)
	{
		setCapacity(pCapacity);
	}

	/**
	 * crée un nouveau CD avec un capacity donnée
	 * @param	pCapacity	la capacité du CD en minutes
	 */
	public Cd(double pCapacity)
	{
		setCapacity(pCapacity);
	}

	/**
	 * ajoute une chanson au CD s'il y a assez de place disponible
	 * @param	pSong	la chanson à ajouter
	 */
	public void addSong(Song pSong)
	{
		if(calculateDuration()+pSong.getDuration()<=capacity)
			super.addSong(pSong);
	}

	/**
	 * modifie la capacité du CD
	 * @param	pCapacity	la capacité du CD en secondes
	 */
	public void setCapacity(int pCapacity)
	{
		capacity=pCapacity;
	}

	/**
	 * modifie la capacité du CD
	 * @param	pCapacity	la capacité du CD en minutes
	 */
	public void setCapacity(double pCapacity)
	{
		/*int minutes = (int) pCapacity;
		int secondes = (int) ((pCapacity-minutes)*60);
		capacity = minutes*60 + secondes;*/
		capacity = (int) (pCapacity*60);
	}

	/**
	 * retourne la capacité du CD
	 * @return	la capacité du CD en secondes
	 */
	public int getCapacity()
	{
		return capacity;
	}

}