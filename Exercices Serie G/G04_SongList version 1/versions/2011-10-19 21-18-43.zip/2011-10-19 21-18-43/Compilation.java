/**
 * Write a description of class "Compilation" here.
 * 
 * @author     robertfisch
 * @version    18/10/2011 20:51:54
 */
public class Compilation extends SongList
{
}