import java.util.ArrayList;
/**
 * Write a description of class "SongList" here.
 * 
 * @author     robertfisch
 * @version    18/10/2011 20:52:08
 */
public class SongList
{

	protected ArrayList<Song> songs = new ArrayList<Song>();

	public int calculateDuration()
	{
		int total = 0;
		for(int i=0;i<songs.size();i++)
			total+=songs.get(i).getDuration();
		return total;
	}

	public void addSong(Song song)
	{
		if(!songs.contains(song))
			songs.add(song);
	}
}