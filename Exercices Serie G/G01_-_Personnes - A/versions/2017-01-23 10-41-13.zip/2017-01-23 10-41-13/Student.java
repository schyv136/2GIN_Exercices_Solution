/**
 * Write a description of class "Student" here.
 * 
 * @author     robertfisch
 * @version    27/08/2012 20:12:47
 */
public class Student extends Person
{
	private String affectedSchool;
	private String affectedClass;
}