/**
 * Write a description of class "Client" here.
 * 
 * @author     robertfisch
 * @version    27/08/2012 20:23:23
 */
public class Client extends Person
{
	private String bloodGroup;
}