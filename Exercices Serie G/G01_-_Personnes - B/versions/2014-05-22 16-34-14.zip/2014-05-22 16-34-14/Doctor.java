/**
 * Write a description of class "Docter" here.
 * 
 * @author     robertfisch
 * @version    27/08/2012 20:25:56
 */
public class Doctor extends Employee
{
	private String affectedHospital;
}