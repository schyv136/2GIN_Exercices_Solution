/**
 * Write a description of class "Employee" here.
 * 
 * @author     robertfisch
 * @version    27/08/2012 20:23:20
 */
public class Employee extends Person
{
	private String IBAN;
	private String BIC;
}