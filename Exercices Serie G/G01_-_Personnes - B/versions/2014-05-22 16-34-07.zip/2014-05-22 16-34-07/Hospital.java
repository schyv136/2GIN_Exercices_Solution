import java.util.ArrayList;

public class Hospital {
	private ArrayList<Doctor> alDoctors;
	private ArrayList<Client> alClients;
	private ArrayList<Employee> alEmployees;
}