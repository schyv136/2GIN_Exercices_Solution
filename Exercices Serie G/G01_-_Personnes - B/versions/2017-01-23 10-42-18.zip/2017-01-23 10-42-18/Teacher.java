/**
 * Write a description of class "Teacher" here.
 * 
 * @author     robertfisch
 * @version    27/08/2012 20:13:00
 */
public class Teacher extends Employee
{
	private String UNTIS;
	private String affectedSchool;
}