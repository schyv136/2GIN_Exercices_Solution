import java.util.ArrayList;

public class School {
	private ArrayList<Teacher> alTeachers;
	private ArrayList<Student> alStudents;
	private ArrayList<Employee> alEmployees;	
}