package model;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author robertfisch
 */
public class Block extends MovingObject {

    protected int width;
    protected int height;

    public Block(int x, int y, int width, int height) {
        super(x, y);
        this.width=width;
        this.height=height;
        
        stepY = -3;
    }
    
    public void draw(Graphics g)
    {
        g.setColor(Color.GREEN);
        g.fillRect(x, y, width, height);
        g.setColor(Color.BLACK);
        g.drawRect(x, y, width, height);
    }
    
    public boolean isTouching(Ball ball)
    {
        /*boolean result = false;
        for(int i=0; i<360; i++)
        {
            int cx = (int) (ball.x+ball.getRadius()*Math.cos(i/180.*Math.PI));
            int cy = (int) (ball.y+ball.getRadius()*Math.sin(i/180.*Math.PI));
            //System.out.println(ball.x+" --> "+cx+" --"+i);
            if(x<=cx && cx<=x+width &&
               y<=cy && cy<=y+height)
            {
                result = true;
            }
        }
        return result;*/
        int cx = ball.x;
        int cy = ball.y+ball.getRadius();
        //System.out.println(ball.x+" --> "+cx+" --"+i);
        if(x<=cx && cx<=x+width &&
           y<=cy && cy<=y+height)
        {
            return true;
        }
        return false;
    }
    
}