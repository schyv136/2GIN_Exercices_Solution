package model;


import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author robertfisch
 */
public class Ball extends MovingObject
{
    private int radius;
    
    public Ball(int x, int y, int radius) {
        super(x, y);
        this.radius=radius;
        
        stepY = 5;
    }
    
    public void move(int width)
    {
        super.move();
        if(x<radius) x=radius;
        else if(x+radius>width) x=width-radius;
    }
    
    public void draw(Graphics g)
    {
        g.setColor(Color.RED);
        g.fillOval(x-radius, y-radius, 2*radius, 2*radius);
        g.setColor(Color.BLACK);
        g.drawOval(x-radius, y-radius, 2*radius, 2*radius);
    }

    public int getRadius() {
        return radius;
    }
    
}