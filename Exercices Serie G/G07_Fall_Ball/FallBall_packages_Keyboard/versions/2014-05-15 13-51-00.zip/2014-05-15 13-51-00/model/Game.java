package model;

import java.awt.Graphics;
import java.util.ArrayList;

/**
 *
 * @author robertfisch
 */
public class Game 
{
    private ArrayList<Block> alBlocks = new ArrayList<Block>();
    private Ball ball = null;
    
    private int points = 0;
    private int lives = 3;
    
    private int ballSpeed = 10;

    public Game(int width, int height) 
    {
        int h = height/10;
        for(int i=0; i<10; i++)
        {
            int x = (int) (Math.random()*width)/2;
            int w = (int) (Math.random()*(width-x)/3*2);
            Block block = new Block(x, i*h, w, h/3);
            alBlocks.add(block);
        }
        
        int x = width/2;
        int y = height/2;
        ball = new Ball(x, y, h/3);
    }
    
    public void draw(Graphics g)
    {
        for(int i=0; i<alBlocks.size(); i++)
        {
            alBlocks.get(i).draw(g);
        }
        if(ball!=null)
        {
            ball.draw(g);
        }
    }
    
    public void move(int width, int height)
    {
        boolean touching=false;
        for(int i=0; i<alBlocks.size(); i++)
        {
            Block block = alBlocks.get(i);
            block.move();
            if(block.y<0)
            {
                block.y=height;
                block.x=(int) (Math.random()*width/2);
                block.width=(int) (Math.random()*(width-block.stepX)/3*2);
                points++;
                if(points%100==0) 
                {
                    lives++;
                    for(int j=0; j<alBlocks.size(); j++)
                    {
                        alBlocks.get(j).stepY = alBlocks.get(j).stepY-1;
                    }
                    ballSpeed+=1;
                }
            }
            if(block.isTouching(ball))
            {
                touching = true;
                ball.stepY = block.stepY;
            }
        }
        if(touching==false)
        {
            ball.stepY=5;
            //ball.setStepX(0);
        }
        ball.move(width);
        if(ball.y<0 || ball.y>height) 
        {
            lives--;
            ball.y=height/2;
            ball.x=width/2;
        }
    }
    
    public void ballLeft()
    {
        ball.stepX=-ballSpeed;
    }
    
    public void ballRight()
    {
        ball.stepX=ballSpeed;
    }
    
    public int getPoints() {
        return points;
    }

    public int getLives() {
        return lives;
    }

    public void ballStop() {
        ball.stepX=0;
    }
    
    
}