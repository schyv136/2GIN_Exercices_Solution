import java.util.ArrayList;
/**
 * Write a description of class "IncriptionList" here. 
 * 
 * @author     robertfisch, Georges Kugener
 * @version    01/02/2011 08:44:34
 */
public class InscriptionList 
{
	private ArrayList<Participant> alParticipants = new ArrayList<Participant>();

        
	public void add(Participant pParticipant)
	{
                alParticipants.add(pParticipant);
	}

        
        public void remove(int i)
	{
		alParticipants.remove(alParticipants.get(i));
	}

        
	public Participant getEldest()
	{
		if (alParticipants.size()>0) 
		{
			Participant eldest = alParticipants.get(0);
			for(int i=1 ; i<alParticipants.size() ; i++)
			{
				if (alParticipants.get(i).getBirthYear()<eldest.getBirthYear())
					eldest=alParticipants.get(i);		
			}
			return eldest;
		}
		else return null;
	}

        
	public Participant getYoungest()
	{
		if (alParticipants.size()>0) 
		{
			Participant youngest = alParticipants.get(0);
			for(int i=1 ; i<alParticipants.size() ; i++)
			{
				if (alParticipants.get(i).getBirthYear()>youngest.getBirthYear())
					youngest=alParticipants.get(i);		
			}
			return youngest;
		}
		else return null;
	}
        
        public int searchByBirthYear(int pBirthYear)
        {
            boolean found = false;
            int i = 0;
            while ( (!found) && (i < alParticipants.size()))
                if (pBirthYear == alParticipants.get(i).getBirthYear())
                    found = true;
                else
                    i++;
            if (found)
                return i;
            else
                return -1;
        }
        
        public int searchByName(String pName)
        {
            boolean found = false;
            int i = 0;
            while ( (!found) && (i < alParticipants.size()))
                if (pName.equals(alParticipants.get(i).getName()))
                    found = true;
                else
                    i++;
            if (found)
                return i;
            else
                return -1;
        }
        
        
        public void sortByBirthYear()
        {
            int size = alParticipants.size();
            for (int i = 0; i <= size-2; i++)
            {
                // recherche de la position du minimum (derrière la position i)
                int positionMinimum = i;
                for (int j = i+1; j <= size-1; j++)
                    if ( alParticipants.get(j).getBirthYear() <  
                         alParticipants.get(positionMinimum).getBirthYear() )
                        positionMinimum = j; 
                //échange si nécessaire
                if (positionMinimum != i)
                {
                   // permutation: version standard
                   Participant temp = alParticipants.get(positionMinimum);
                   alParticipants.set(positionMinimum, alParticipants.get(i));
                   alParticipants.set(i, temp);

                   // permutation: version alternative
                   // Cette version profite du fait que set retourne 
                   // l'objet qui est remplacé comme résultat.
                   //persons.set(i,persons.set(positionMinimum, persons.get(i)));
                }          
            }
        }
        
        
        public void sortByName()
        {
            int size = alParticipants.size();
            for (int i = 0; i <= size-2; i++)
            {
                // recherche de la position du minimum (derrière la position i)
                int positionMinimum = i;
                for (int j = i+1; j <= size-1; j++)
                    if ( alParticipants.get(j).getName().compareTo( 
                         alParticipants.get(positionMinimum).getName()) < 0 )
                        positionMinimum = j; 
                //échange si nécessaire
                if (positionMinimum != i)
                {
                   // permutation: version standard
                   Participant temp = alParticipants.get(positionMinimum);
                   alParticipants.set(positionMinimum, alParticipants.get(i));
                   alParticipants.set(i, temp);

                   // permutation: version alternative
                   // Cette version profite du fait que set retourne 
                   // l'objet qui est remplacé comme résultat.
                   //persons.set(i,persons.set(positionMinimum, persons.get(i)));
                }          
            }
        }
        
        
        public Object[] toArray()
        {
                return alParticipants.toArray();
        }

}