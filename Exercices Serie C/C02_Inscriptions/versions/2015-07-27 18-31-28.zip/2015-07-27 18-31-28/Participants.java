import java.util.ArrayList;
/**
 * Write a description of class "IncriptionList" here.
 * 
 * @author     robertfisch
 * @version    01/02/2011 08:44:34
 */
public class Participants 
{
	private ArrayList<Participant> alParticipants = new ArrayList<Participant>();

	public void add(Participant pParticipant)
	{
		alParticipants.add(pParticipant); 
	}

	public void remove(int i)
	{
		alParticipants.remove(i);
	}

        public int size()
	{
		return alParticipants.size();
	}

        public Participant getParticipant(int pPosition)
	{
		return alParticipants.get(pPosition);
	}

	public Participant getEldest()
	{
		if (alParticipants.size()>0) 
		{
			Participant eldest = alParticipants.get(0);
			for(int i=1 ; i<alParticipants.size() ; i++)
			{
				if (alParticipants.get(i).getBirthYear()<eldest.getBirthYear())
                                {
					eldest=alParticipants.get(i);
                                }
			}
			return eldest;
		}
		else return null;
	}

	public Participant getYoungest()
	{
		if (alParticipants.size()>0) 
		{
			Participant youngest = alParticipants.get(0);
			for(int i=1 ; i<alParticipants.size() ; i++)
			{
				if (alParticipants.get(i).getBirthYear()>youngest.getBirthYear())
                                {
					youngest=alParticipants.get(i);
                                }
			}
			return youngest;
		}
		else 
                {
                    return null;
                }
	}

	
}