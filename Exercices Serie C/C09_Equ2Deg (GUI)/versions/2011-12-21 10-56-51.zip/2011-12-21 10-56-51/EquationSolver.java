/**
 * Classe qui sert à résoudre des équations de la forme: 
 *   ax^2 + bx + c = 0   ( pour a,b,c ∈ IR )
 * 
 * @author     fabfr
 * @version    02/02/2011 
 */
public class EquationSolver
{
	/**	coefficients de l'équation */
	private double a,b,c;
	/**	solutions de l'équation */
	private double x1,x2;
	/**	nombre (et type) de solutions de l'équation 
	 * 	0,1,2	équation du second degré 
	 * 	10		équation du premier degré - équation impossible, S=vide
	 * 	11		équation du premier degré - une solution
	 * 	12		équation du premier degré - équation indéterminable, S=IR
	 * 	-1		équation pas encore résolue (c.-à-d. solve() pas encore exécuté pour ces valeurs)
	 */	
	private int numberOfSolutions;

	/**
	 * Constructeur: initialise les attributs	  
	 * @param pA   valeur pour le coefficient a
	 * @param pB   valeur pour le coefficient b
	 * @param pC   valeur pour le coefficient c
	 */
	public EquationSolver(double pA, double pB, double pC)
	{
		setEquation (pA,pB,pC);
	}

	/**
	 * Réinitialise les attributs avec les données d'une nouvelle équation	  
	 * @param pA   valeur pour le coefficient a
	 * @param pB   valeur pour le coefficient b
	 * @param pC   valeur pour le coefficient c
	 */
	public void setEquation(double pA, double pB, double pC)
	{
		a = pA;
		b = pB;
		c = pC;
		numberOfSolutions = -1; //équation pas encore résolue
	     //initialisation supplémentaire (pas nécessaire)
		x1=Double.NEGATIVE_INFINITY;
		x2=Double.NEGATIVE_INFINITY;

		//solve();  //autre possibilité pour garantir que les résultats soient corrects
		
		//pas recommandé - pour pouvoir intégrer la classe dans d'autres interfaces 
		//showSolution();
	}

	/**
	 * Accesseur pour numberOfSolutions 
	 * @return                le nombre de solutions trouvées (voir attribut 
	 */
	public int getNumberOfSolutions()
	{  return numberOfSolutions;	}

	/**
	 *Accesseur pour x1
	 * @return                la première solution de l'équation
	 */
	public double getX1()
	{ return x1; }
	
	/**
	 * Accesseur pour x2
	 * @return                la deuxième solution de l'équation
	 */
	public double getX2()
	{ return x2; }


	/**
	 * Mémorise les solutions de l'équation dans des attributs.
	 */
	public void solve()
	{
		
		if (a!=0) //équation du second degré
		{
			double delta=b*b-4*a*c;
			if (delta==0) 
			{
			   	numberOfSolutions=1;
			   	x1=-b/(2*a);
			}
			else if (delta>0)
			{
				numberOfSolutions=2;
			   	x1=(-b+Math.sqrt(delta))/(2*a);
			   	x2=(-b-Math.sqrt(delta))/(2*a);
			}
			else  numberOfSolutions=0;
		}
		else //a=0 -> équation du premier degré
		{
			if (b==0 && c==0) numberOfSolutions = 12; //0x=0  -> S=IR
			else if (b==0)    numberOfSolutions = 10; //0x!=0 -> S=vide
			else 
			{
				numberOfSolutions = 11;
				x1=-c/b; 
			}						
		}		
	}

	/**
	 * Affiche toutes les solutions de l'équation actuelle précédées 
	 * par une ou plusieurs lignes de messages qui indiquent 
	 * le type de l'équation et le nombre de solutions.
	 */
	public void showSolution()
	{
		solve(); //pour assurer que les résultats soient corrects
		
		System.out.println("Equation :  "+toString());
		
		if (numberOfSolutions<10) 
		     System.out.print("This quadratic equation ");
		else System.out.print("This linear equation ");
		
		if ( numberOfSolutions==0 || numberOfSolutions==10 )      
		     System.out.println("has no real solutions : S={}");
		else if (numberOfSolutions==1 || numberOfSolutions==11)
		     System.out.println("has one real solution : S={"+String.format("%1.3f",x1)+"}");
		     //System.out.println("has one real solution : S={"+x1+"}");
		else if (numberOfSolutions==2)
		     System.out.println("has two real solutions : S={"+String.format("%1.3f",x1)+" ; "+String.format("%1.3f",x2)+"}");
		     //System.out.println("has two real solutions : S={"+x1+" , "+x2+"}");
		else // 0x = 0
		     System.out.println("is indeterminate and has an infinity of real solutions : S=IR");

		System.out.println("======================================================================================");
	}

	/**
	 * retourne l'équation sous forme de texte
	 * @return                la chaîne représentant l'équation
	 */
	public String toString()
	{
		 //return a+" * x^2 + "+b+" * x + "+c+" = 0";
		 //version améliorée:
		 String s="";
		 if (a!=0)
		 { 
		     if (a!=1) s=s+a+"*";
		     s=s+"x^2";

		 }
		 if (b!=0)
		 {
		     if (b>=0  && a!=0) s=s+"+";
		     if (b!=1) s=s+b+"*";
		 	s=s+"x";

		 }
		 if (c!=0 || a==0 && b==0) 
		 {
			if (c>=0 && (a!=0 || b!=0)) s=s+"+";
			s=s+c;
		 }
		 s=s+" = 0";  
		 return s;   
	}

}
	