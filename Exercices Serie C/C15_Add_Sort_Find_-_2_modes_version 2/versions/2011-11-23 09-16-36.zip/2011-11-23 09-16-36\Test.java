public class Test
{

    public static void main(String[] args) 
    {
        Participant josy = new Participant("Josy", "Muller", 1980);
        Participant poli = new Participant("Poli", "Muller", 1985);
        Participant mary = new Participant("Mary", "Muller", 1978);
        InscriptionList insc = new InscriptionList();
        insc.addParticipant(josy);
        insc.addParticipant(poli);
        insc.addParticipant(mary); 
        /*
        for(int i=0 ; i<insc.participants.size() ; i++)
        	System.out.println(insc.participants.get(i));
        */
    }
}