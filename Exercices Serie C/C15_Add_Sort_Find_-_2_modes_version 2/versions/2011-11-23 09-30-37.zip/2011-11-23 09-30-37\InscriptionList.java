import java.util.ArrayList;
/**
 * Write a description of class "IncriptionList" here.
 * 
 * @author     robertfisch
 * @version    01/02/2011 08:44:34
 */
public class InscriptionList 
{
	private ArrayList<Participant> participants = new ArrayList<Participant>();

	public void add(Participant pParticipant)
	{
		participants.add(pParticipant); 
	}

	public void remove(Participant pParticipant)
	{
		participants.remove(pParticipant);
	}

	public Participant getEldest()
	{
		if (participants.size()>0) 
		{
			Participant eldest = participants.get(0);
			for(int i=1 ; i<participants.size() ; i++)
			{
				if (participants.get(i).getBirthYear()<eldest.getBirthYear())
					eldest=participants.get(i);		
			}
			return eldest;
		}
		else return null;
	}

	public Participant getYoungest()
	{
		if (participants.size()>0) 
		{
			Participant youngest = participants.get(0);
			for(int i=1 ; i<participants.size() ; i++)
			{
				if (participants.get(i).getBirthYear()>youngest.getBirthYear())
					youngest=participants.get(i);		
			}
			return youngest;
		}
		else return null;
	}

	
}